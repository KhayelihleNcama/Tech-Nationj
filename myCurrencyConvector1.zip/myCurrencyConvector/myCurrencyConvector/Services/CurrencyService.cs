﻿using System.Net.Http.Json;
using myCurrencyConvector.Models;

namespace myCurrencyConvector.Services
{
    public interface ICurrencyService
    {
        Task<decimal> GetRateAsync(string from, string to);
    }
    public class CurrencyService: ICurrencyService
    {
        private readonly HttpClient _http;
        public CurrencyService (HttpClient http)
        {
            _http = http;
        }
        public async Task<decimal> GetRateAsync(string from, string to)
        {
            //1.if currency is the same examples ZAR -> ZAR
            if (from == to)
            {
                return 1m;
            }
            var url = $"latest?base={from}&symbols={to}";
            Console.WriteLine(_http.BaseAddress + url);
            var data = await _http.GetFromJsonAsync<RateResponse>(url);
            
            if(data == null || !data.Rates.TryGetValue(to,out var rates))
            {
                throw new InvalidOperationException("Rate not Available");
            }
            return rates;
        }
    }
}
