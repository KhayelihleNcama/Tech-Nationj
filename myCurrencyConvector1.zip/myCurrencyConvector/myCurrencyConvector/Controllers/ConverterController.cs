﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using myCurrencyConvector.Models;
using myCurrencyConvector.Services;


namespace myCurrencyConvector.Controllers
{
    public class ConverterController : Controller
    {
        private static readonly Dictionary<string, string> currencyCode = new()
        {
             ["AUD"] = "Australian Dollar",
  ["BRL"] = "Brazilian Real",
  ["CAD"] = "Canadian Dollar",
  ["CHF"] = "Swiss Franc",
  ["CNY"] ="Chinese Renminbi Yuan",
  ["CZK"]  = "Czech Koruna",
  ["DKK"] = "Danish Krone",
  ["EUR"] = "Euro",
  ["GBP"] = "British Pound",
  ["HKD"] ="Hong Kong Dollar",
  ["HUF"] = "Hungarian Forint",
  ["IDR"]="Indonesian Rupiah",
  ["ILS"]= "Israeli New Shekel",
  ["INR"]= "Indian Rupee",
  ["ISK"]= "Icelandic Króna",
  ["JPY"]= "Japanese Yen",
  ["KRW"]= "South Korean Won",
  ["MXN"]= "Mexican Peso",
  ["MYR"]= "Malaysian Ringgit",
  ["NOK"]= "Norwegian Krone",
  ["NZD"]= "New Zealand Dollar",
  ["PHP"]= "Philippine Peso",
  ["PLN"] ="Polish Złoty",
  ["RON"]= "Romanian Leu",
  ["SEK"]= "Swedish Krona",
  ["SGD"]= "Singapore Dollar",
  ["THB"]= "Thai Baht",
  ["TRY"] = "Turkish Lira",
  ["USD"] ="United States Dollar",
  ["ZAR"] = "South African Rand"
        };
        // GET: myCurrencyConvector
        [HttpGet]
        public IActionResult Index()
        {
            var model = new ConvertViewModel();
            LoadCurrencies(model);

            return View(model);
        }

        private readonly ICurrencyService _CurrencyService;
        public ConverterController(ICurrencyService currencyService)
        {
            _CurrencyService = currencyService;
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult>Index(ConvertViewModel model)
        {
            LoadCurrencies(model);
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            try
            {
                var rate = await _CurrencyService.GetRateAsync(model.From, model.To);
                model.rate = rate;

                model.results = Math.Round(model.Amount!.Value * rate, 2);
            }
            catch (Exception ex) when (ex is HttpRequestException
                              or InvalidOperationException
                              or TaskCanceledException)
            {
                Console.WriteLine($"Rate error: {ex.GetType().Name}: {ex.Message}");
                ModelState.AddModelError(string.Empty, $"{ex.GetType().Name}: {ex.Message}");
            }
            return View(model);
        }

        
        private void LoadCurrencies(ConvertViewModel model)
        {
            model.Currencies = currencyCode
                .OrderBy(c => c.Key)
                .Select(c => new SelectListItem($"{c.Key} - {c.Value}",c.Key)).ToList();
        }
      

        
        
    }
}
