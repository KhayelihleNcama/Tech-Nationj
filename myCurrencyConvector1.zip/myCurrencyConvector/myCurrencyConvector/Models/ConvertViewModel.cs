﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace myCurrencyConvector.Models
{
    public class ConvertViewModel
    {
        [Required (ErrorMessage = "Please Enter Amount")]
        [Range(typeof(decimal), "0.01", "1000000000.00",
        ErrorMessage = "Amount must be between 0.01 and 1,000,000,000.")]
        public decimal? Amount{ get; set;}

        [Required(ErrorMessage = "Please choose a currency to convert from.")]
        public string? From { get; set; } = "USD";


        [Required(ErrorMessage = "Please choose a currency to convert from.")]
        public string? To { get; set; } = "ZAR";

        [Range(typeof(decimal), "0.01","1000000000.00")]
        public decimal? convectedAmount {  get; set;}

        public List<SelectListItem> Currencies { get; set; } = new();
        public decimal? rate { get; set; }
        public decimal? results {  get; set; }

    }
}
