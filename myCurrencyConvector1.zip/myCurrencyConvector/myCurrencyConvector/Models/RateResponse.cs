﻿namespace myCurrencyConvector.Models
{
    public class RateResponse
    {
        public string Base { get; set; } = "";
        public string Date { get; set; } = "";
        public Dictionary<string, decimal> Rates { get; set; } = new();
    }
}
